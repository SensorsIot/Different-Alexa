var searchData=
[
  ['reset',['reset',['../class_j_q6500___serial.html#a656a4a915ca0ca29ef6d6cb3311efa42',1,'JQ6500_Serial']]],
  ['restart',['restart',['../class_j_q6500___serial.html#a80a2ef4fbb20aa984eca0ddb03328718',1,'JQ6500_Serial']]]
];
